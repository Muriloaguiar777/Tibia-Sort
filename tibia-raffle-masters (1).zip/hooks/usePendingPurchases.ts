import { useState, useEffect, useCallback } from 'react';
import { PendingPurchase } from '../types';
import * as raffleService from '../services/raffleService';

export const usePendingPurchases = () => {
  const [pending, setPending] = useState<PendingPurchase[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const refreshPending = useCallback(async () => {
    try {
      setLoading(true);
      const data = await raffleService.getPendingPurchases();
      setPending(data);
      setError(null);
    } catch (e) {
      setError('Failed to fetch pending purchases.');
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refreshPending();
  }, [refreshPending]);

  return { pending, loading, error, refreshPending };
};
