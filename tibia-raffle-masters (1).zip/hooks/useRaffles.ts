
import { useState, useEffect, useCallback } from 'react';
import { RaffleItem } from '../types';
import * as raffleService from '../services/raffleService';

export const useRaffles = () => {
  const [raffles, setRaffles] = useState<RaffleItem[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const refreshRaffles = useCallback(async () => {
    try {
      setLoading(true);
      const data = await raffleService.getRaffles();
      setRaffles(data.sort((a, b) => new Date(a.endDate).getTime() - new Date(b.endDate).getTime()));
      setError(null);
    } catch (e) {
      setError('Failed to fetch raffles.');
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refreshRaffles();
  }, [refreshRaffles]);

  return { raffles, loading, error, refreshRaffles };
};
