
import React, { createContext, useState, useEffect } from 'react';

// This is a simplified, client-side-only auth system.
// In a real-world app, this would involve server-side validation and JWTs.

const AUTH_KEY = 'tibiaRaffleAdminAuth';
// The secure password for the admin panel.
const ADMIN_PASSWORD = 'tibiaadmin'; 

interface AuthContextType {
  isAuthenticated: boolean;
  login: (password: string) => Promise<boolean>;
  logout: () => void;
}

export const AuthContext = createContext<AuthContextType | null>(null);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);

  useEffect(() => {
    // Check for auth status on initial load
    try {
      const storedAuth = sessionStorage.getItem(AUTH_KEY);
      if (storedAuth === 'true') {
        setIsAuthenticated(true);
      }
    } catch (error) {
        console.error("Could not access session storage. Authentication may not persist.", error);
    }
  }, []);

  const login = async (password: string): Promise<boolean> => {
    // Simulate an async API call
    return new Promise(resolve => {
        setTimeout(() => {
            if (password === ADMIN_PASSWORD) {
                try {
                    sessionStorage.setItem(AUTH_KEY, 'true');
                    setIsAuthenticated(true);
                    resolve(true);
                } catch (error) {
                    console.error("Could not access session storage. Login will not persist.", error);
                    // Still allow login for this session even if storage fails
                    setIsAuthenticated(true);
                    resolve(true);
                }
            } else {
                resolve(false);
            }
        }, 500); // Simulate network delay
    });
  };

  const logout = () => {
    try {
        sessionStorage.removeItem(AUTH_KEY);
    } catch (error) {
        console.error("Could not access session storage to log out.", error);
    }
    setIsAuthenticated(false);
  };

  const value = { isAuthenticated, login, logout };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};
