import React, { useState } from 'react';
import { useRaffles } from '../hooks/useRaffles';
import RaffleCard from '../components/RaffleCard';
import { addTicketHolder, formatCurrency, convertCurrency, addPendingPurchase } from '../services/raffleService';
import Modal from '../components/ui/Modal';
import Input from '../components/ui/Input';
import Button from '../components/ui/Button';
import { RaffleItem, Currency } from '../types';
import { TicketIcon } from '../components/icons/TicketIcon';

const HomePage: React.FC = () => {
  const { raffles, loading, error, refreshRaffles } = useRaffles();
  const [isBuyModalOpen, setBuyModalOpen] = useState(false);
  const [selectedRaffle, setSelectedRaffle] = useState<RaffleItem | null>(null);
  const [characterName, setCharacterName] = useState('');
  const [buyError, setBuyError] = useState('');
  const [paymentCurrency, setPaymentCurrency] = useState<Currency>('TC');
  const [purchaseStatus, setPurchaseStatus] = useState<'form' | 'processing' | 'pending'>('form');
  const [pendingPurchaseDetails, setPendingPurchaseDetails] = useState<{ currency: Currency; amount: number; raffleName: string; } | null>(null);


  const handleBuyClick = (raffle: RaffleItem) => {
    setSelectedRaffle(raffle);
    setCharacterName('');
    setBuyError('');
    setPaymentCurrency(raffle.ticketCurrency);
    setPurchaseStatus('form');
    setPendingPurchaseDetails(null);
    setBuyModalOpen(true);
  };
  
  const handleCloseModal = () => {
    setBuyModalOpen(false);
    // Delay state reset to allow modal fade-out animation
    setTimeout(() => {
        setPurchaseStatus('form');
        setBuyError('');
        setPendingPurchaseDetails(null);
    }, 300);
  };

  const handleConfirmBuy = async () => {
    if (!characterName.trim()) {
      setBuyError('Character name is required.');
      return;
    }
    if (selectedRaffle) {
      setBuyError('');
      setPurchaseStatus('processing');
      try {
        const convertedPrice = convertCurrency(selectedRaffle.ticketPrice, selectedRaffle.ticketCurrency, paymentCurrency);
        await addPendingPurchase(selectedRaffle.id, selectedRaffle.name, characterName.trim(), paymentCurrency, convertedPrice);
        
        setPendingPurchaseDetails({
          currency: paymentCurrency,
          amount: convertedPrice,
          raffleName: selectedRaffle.name
        });
        
        setPurchaseStatus('pending');
      } catch (err: any) {
        setBuyError(err.message || 'Failed to submit purchase for verification.');
        setPurchaseStatus('form');
      }
    }
  };

  const renderModalContent = () => {
    switch (purchaseStatus) {
        case 'pending':
            if (!pendingPurchaseDetails) return null;

            const isBRL = pendingPurchaseDetails.currency === 'BRL';

            return (
                <div className="p-8 text-center">
                    <h3 className="text-2xl font-bold text-yellow-400 mb-4">Purchase Submitted!</h3>
                    <p className="text-gray-300 mb-2">Your ticket for <strong className="text-white">{pendingPurchaseDetails.raffleName}</strong> is now pending verification.</p>
                    <p className="text-gray-300 mb-6">To complete your purchase, please make the payment as instructed below.</p>
                    
                    {isBRL ? (
                         <div className="p-4 bg-blue-900/50 border border-blue-500 rounded-md mb-6 text-left space-y-2">
                            <p className="font-semibold text-blue-200 text-center text-lg">Real Money (Pix) Transfer</p>
                            <p className="text-gray-200">Please transfer <strong className="text-yellow-400">{formatCurrency(pendingPurchaseDetails.amount, 'BRL')}</strong> to:</p>
                            <ul className="list-disc list-inside text-gray-300 pl-2">
                                <li><strong>Chave Pix (CPF):</strong> 549.184.468-33</li>
                                <li><strong>Nome:</strong> Murilo de Aguiar</li>
                            </ul>
                             <p className="text-xs text-yellow-300/80 pt-2">Your ticket will be approved once the admin verifies the transaction.</p>
                        </div>
                    ) : (
                        <div className="p-4 bg-purple-900/50 border border-purple-500 rounded-md mb-6 text-left space-y-2">
                            <p className="font-semibold text-purple-200 text-center text-lg">Tibia Coin Transfer</p>
                            <p className="text-gray-200">Please transfer <strong className="text-yellow-400">{formatCurrency(pendingPurchaseDetails.amount, 'TC')}</strong> to the character:</p>
                             <ul className="list-disc list-inside text-gray-300 pl-2">
                                 <li><strong>Character Name:</strong> Sortbank Yonabra</li>
                             </ul>
                            <p className="text-xs text-yellow-300/80 pt-2">Your ticket will be approved once the admin verifies the transaction in the Tibia Coin history.</p>
                        </div>
                    )}

                    <Button onClick={handleCloseModal} variant="primary">Okay, I Understand</Button>
                </div>
            );
        case 'form':
        case 'processing':
        default:
            return (
                <div className="p-6">
                    <p className="text-gray-300 mb-4 text-center">Enter your Tibia character name and choose your payment currency.</p>
                    
                     <div className="mb-4 p-4 bg-gray-900/50 border border-gray-700 rounded-md">
                        <h4 className="font-semibold text-lg text-gray-200 mb-3">Choose Payment Currency</h4>
                        <div className="space-y-2">
                            {(['TC', 'BRL'] as Currency[]).map(currency => {
                                const convertedPrice = convertCurrency(selectedRaffle!.ticketPrice, selectedRaffle!.ticketCurrency, currency);
                                return (
                                    <label key={currency} className="flex items-center p-3 bg-gray-800 rounded-md cursor-pointer hover:bg-gray-700/50 transition-colors">
                                        <input
                                            type="radio"
                                            name="paymentCurrency"
                                            value={currency}
                                            checked={paymentCurrency === currency}
                                            onChange={() => setPaymentCurrency(currency)}
                                            className="h-4 w-4 text-yellow-500 bg-gray-700 border-gray-600 focus:ring-yellow-600 focus:ring-offset-gray-800"
                                            aria-label={`Pay with ${currency}`}
                                        />
                                        <span className="ml-3 text-white flex-grow">{currency}</span>
                                        <span className="font-semibold text-yellow-400">{formatCurrency(convertedPrice, currency)}</span>
                                    </label>
                                );
                            })}
                        </div>
                    </div>

                    <div className="p-4 bg-gray-900/50 border border-gray-700 rounded-md mb-4 text-center">
                        <p className="font-semibold text-yellow-300">Admin Verification Required</p>
                        <p className="text-gray-400 text-sm mt-1">All purchases require manual verification by an admin after payment. Instructions will be shown on the next screen.</p>
                    </div>

                    <Input
                      type="text"
                      placeholder="Character Name"
                      value={characterName}
                      onChange={e => setCharacterName(e.target.value)}
                      className="w-full"
                      aria-label="Character Name"
                    />
                    {buyError && <p className="text-red-500 text-sm mt-2">{buyError}</p>}
                    <div className="mt-6 flex justify-end space-x-4">
                      <Button onClick={handleCloseModal} variant="secondary">Cancel</Button>
                      <Button onClick={handleConfirmBuy} variant="primary" disabled={purchaseStatus === 'processing'}>
                        {purchaseStatus === 'processing' ? 'Processing...' : (
                            <><TicketIcon className="w-5 h-5 mr-2" /> Confirm Purchase</>
                        )}
                      </Button>
                    </div>
                </div>
            );
    }
  }

  if (loading) return <div className="text-center text-xl p-10">Loading legendary treasures...</div>;
  if (error) return <div className="text-center text-red-500 text-xl p-10">{error}</div>;

  const activeRaffles = raffles.filter(r => new Date(r.endDate) > new Date() && !r.winner);
  const finishedRaffles = raffles.filter(r => new Date(r.endDate) <= new Date() || !!r.winner);

  const modalTitle = purchaseStatus === 'form' || purchaseStatus === 'processing'
    ? (selectedRaffle ? `Buy Ticket for ${selectedRaffle.name}` : 'Buy Ticket')
    : 'Action Required';

  return (
    <div>
      <h1 className="text-4xl font-bold text-yellow-400 text-center mb-8 tracking-wide font-serif">Ongoing Raffles</h1>
      {activeRaffles.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {activeRaffles.map(raffle => (
            <RaffleCard key={raffle.id} raffle={raffle} onBuyClick={handleBuyClick} />
          ))}
        </div>
      ) : (
        <p className="text-center text-gray-400 col-span-full">No active raffles at the moment. Check back soon!</p>
      )}

       <h1 className="text-4xl font-bold text-yellow-400 text-center mt-16 mb-8 tracking-wide font-serif">Finished Raffles</h1>
        {finishedRaffles.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {finishedRaffles.map(raffle => (
                    <RaffleCard key={raffle.id} raffle={raffle} onBuyClick={() => {}} />
                ))}
            </div>
        ) : (
            <p className="text-center text-gray-400 col-span-full">No raffles have finished yet.</p>
        )}


      {selectedRaffle && (
        <Modal isOpen={isBuyModalOpen} onClose={handleCloseModal} title={modalTitle}>
            {renderModalContent()}
        </Modal>
      )}
    </div>
  );
};

export default HomePage;
