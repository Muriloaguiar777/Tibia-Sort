import React, { useState, useCallback } from 'react';
import { useRaffles } from '../hooks/useRaffles';
import { usePendingPurchases } from '../hooks/usePendingPurchases';
import { RaffleItem, Participant, Currency, PendingPurchase } from '../types';
import * as raffleService from '../services/raffleService';
import { generateWinnerAnnouncement } from '../services/geminiService';
import Button from '../components/ui/Button';
import Modal from '../components/ui/Modal';
import Input from '../components/ui/Input';
import { PlusIcon } from '../components/icons/PlusIcon';
import { TrashIcon } from '../components/icons/TrashIcon';
import { PencilIcon } from '../components/icons/PencilIcon';
import { TrophyIcon } from '../components/icons/TrophyIcon';
import { UsersIcon } from '../components/icons/UsersIcon';
import { DownloadIcon } from '../components/icons/DownloadIcon';

const CheckIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M4.5 12.75l6 6 9-13.5" />
    </svg>
);

const XIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
    </svg>
);

const ExternalLinkIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M13.5 6H5.25A2.25 2.25 0 0 0 3 8.25v10.5A2.25 2.25 0 0 0 5.25 21h10.5A2.25 2.25 0 0 0 18 18.75V10.5m-4.5 0V6.75A.75.75 0 0 1 14.25 6h3.75m-3.75 0L18 9.75" />
    </svg>
);


const PendingVerifications: React.FC<{
    pendingPurchases: PendingPurchase[];
    onApprove: (purchase: PendingPurchase) => Promise<void>;
    onReject: (purchase: PendingPurchase) => Promise<void>;
    loading: boolean;
}> = ({ pendingPurchases, onApprove, onReject, loading }) => {
    if (loading) return <div className="text-center p-4">Loading pending verifications...</div>;
    if (pendingPurchases.length === 0) return null;

    return (
        <div className="mb-8 p-6 bg-yellow-900/20 border border-yellow-500/50 rounded-lg">
            <h2 className="text-2xl font-bold text-yellow-400 font-serif mb-4">Pending Payment Verifications</h2>
             <div className="mb-4 text-sm text-yellow-200/80 space-y-2">
                <p>The entries below require manual payment verification. Check your Tibia Coin history or bank account for a transaction matching the amount. Approve the purchase once confirmed.</p>
                <p className="font-bold text-yellow-300">Security Warning: This app will NEVER ask for your Tibia password.</p>
            </div>
            <div className="overflow-x-auto">
                 <table className="w-full text-left text-sm text-gray-200">
                    <thead className="bg-gray-700/50 text-xs text-gray-400 uppercase tracking-wider">
                        <tr>
                            <th className="p-3">Character Name</th>
                            <th className="p-3">Raffle Item</th>
                            <th className="p-3">Amount</th>
                            <th className="p-3 text-center">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {pendingPurchases.map(purchase => (
                            <tr key={purchase.id} className="border-b border-gray-700 hover:bg-gray-700/50">
                                <td className="p-3 font-medium">{purchase.characterName}</td>
                                <td className="p-3 text-gray-400">{purchase.raffleName}</td>
                                <td className="p-3 font-semibold text-yellow-400">{raffleService.formatCurrency(purchase.amount, purchase.currency)}</td>
                                <td className="p-3">
                                    <div className="flex items-center justify-center space-x-2">
                                        {purchase.currency === 'TC' ? (
                                            <a 
                                              href="https://www.tibia.com/account/?subtopic=accountmanagement&page=tibiacoinshistory" 
                                              target="_blank" 
                                              rel="noopener noreferrer" 
                                              className="inline-flex items-center justify-center font-bold rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 transition-all duration-200 bg-blue-600 text-white hover:bg-blue-500 focus:ring-blue-500 px-2 py-1 text-xs"
                                              title="Verify on Tibia.com"
                                            >
                                                <ExternalLinkIcon className="w-4 h-4 mr-1" />
                                                Verify
                                            </a>
                                        ) : (
                                            <span className="inline-flex items-center font-bold px-2 py-1 text-xs text-blue-200 bg-blue-900/50 rounded-md" title="Verify transaction in your bank account">
                                                Verify Pix
                                            </span>
                                        )}
                                        <Button onClick={() => onApprove(purchase)} variant="primary" size="sm" title="Approve Purchase" className="bg-green-600 hover:bg-green-500 focus:ring-green-500">
                                            <CheckIcon className="w-4 h-4"/>
                                        </Button>
                                         <Button onClick={() => onReject(purchase)} variant="danger" size="sm" title="Reject Purchase">
                                            <XIcon className="w-4 h-4" />
                                        </Button>
                                    </div>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};


const AdminRaffleRow: React.FC<{ raffle: RaffleItem; onEdit: (raffle: RaffleItem) => void; onDelete: (raffle: RaffleItem) => void; onDraw: (raffle: RaffleItem) => void; onViewParticipants: (raffle: RaffleItem) => void; }> = ({ raffle, onEdit, onDelete, onDraw, onViewParticipants }) => {
    const isFinished = new Date(raffle.endDate) < new Date() || !!raffle.winner;
    const canViewParticipants = raffle.participants.length > 0;
    const canBeDrawn = isFinished && !raffle.winner && raffle.participants.length >= raffle.minTickets;

    const getStatus = () => {
        if (raffle.winner) {
            return <span className="font-bold text-yellow-400">{raffle.winner.name}</span>;
        }
        if (isFinished) {
            if (raffle.participants.length < raffle.minTickets) {
                 return <span className="text-orange-400">Min. not met</span>;
            }
            return <span className="text-gray-400">Ended</span>;
        }
        return <span className="text-green-400">Active</span>;
    };

    return (
        <tr className={`border-b border-gray-700 ${isFinished ? 'bg-gray-800/50' : 'hover:bg-gray-700/50'}`}>
            <td className="p-3"><img src={raffle.imageUrl} alt={raffle.name} className="w-10 h-10 object-contain bg-gray-900 rounded-md p-1"/></td>
            <td className="p-3 font-medium">{raffle.name}</td>
            <td className={`p-3 font-medium ${canViewParticipants ? 'cursor-pointer hover:text-yellow-400' : ''}`} onClick={() => canViewParticipants && onViewParticipants(raffle)} title={canViewParticipants ? 'View Participants' : ''}>
                {raffle.participants.length} / {raffle.totalTickets}
            </td>
            <td className="p-3">{raffleService.formatCurrency(raffle.ticketPrice, raffle.ticketCurrency)}</td>
            <td className="p-3">{new Date(raffle.endDate).toLocaleString()}</td>
            <td className="p-3">{getStatus()}</td>
            <td className="p-3">
                <div className="flex items-center space-x-2">
                    <Button onClick={() => onViewParticipants(raffle)} disabled={!canViewParticipants} variant="secondary" size="sm" title="View Participants">
                        <UsersIcon className="w-4 h-4" />
                    </Button>
                    <Button onClick={() => onDraw(raffle)} disabled={!canBeDrawn} variant="primary" size="sm" title="Draw Winner">
                        <TrophyIcon className="w-4 h-4" />
                    </Button>
                    <Button onClick={() => onEdit(raffle)} disabled={isFinished} variant="secondary" size="sm" title="Edit Raffle">
                        <PencilIcon className="w-4 h-4" />
                    </Button>
                     <Button onClick={() => onDelete(raffle)} variant="danger" size="sm" title="Delete Raffle">
                        <TrashIcon className="w-4 h-4" />
                    </Button>
                </div>
            </td>
        </tr>
    );
};


const RaffleModal: React.FC<{
    isOpen: boolean;
    onClose: () => void;
    onSave: (raffle: Omit<RaffleItem, 'id' | 'participants' | 'winner'> | (Partial<RaffleItem> & { id: string })) => void;
    raffle: Partial<RaffleItem> | null;
}> = ({ isOpen, onClose, onSave, raffle }) => {
    const [formData, setFormData] = useState<Partial<RaffleItem>>({});
    const [errors, setErrors] = useState<Record<string, string>>({});
    
    const isEditMode = !!raffle?.id;

    React.useEffect(() => {
        if (isOpen) {
            setFormData(raffle || { 
                name: '', 
                imageUrl: '', 
                ticketPrice: 25, 
                ticketCurrency: 'TC',
                totalTickets: 100, 
                minTickets: 10,
                endDate: new Date(Date.now() + 86400000).toISOString() 
            });
        }
    }, [raffle, isOpen]);

    React.useEffect(() => {
        const validate = () => {
            const newErrors: Record<string, string> = {};
            if (!formData.name?.trim()) newErrors.name = "Item name is required.";
            
            if (!formData.imageUrl?.trim()) {
                newErrors.imageUrl = "Image URL is required.";
            } else {
                try {
                    new URL(formData.imageUrl);
                } catch (_) {
                    newErrors.imageUrl = "Please enter a valid URL.";
                }
            }
            if (!formData.ticketPrice || formData.ticketPrice <= 0) newErrors.ticketPrice = "Price must be a positive number.";
            if (!formData.totalTickets || formData.totalTickets <= 0) newErrors.totalTickets = "Total tickets must be a positive number.";
            if (!formData.minTickets || formData.minTickets <= 0) newErrors.minTickets = "Minimum tickets must be a positive number.";
            if (formData.minTickets && formData.totalTickets && formData.minTickets > formData.totalTickets) {
                newErrors.minTickets = "Minimum tickets cannot be more than total tickets.";
            }
            
            if (!isEditMode && (!formData.endDate || new Date(formData.endDate) <= new Date())) {
                newErrors.endDate = "End date must be in the future.";
            } else if (!formData.endDate) {
                newErrors.endDate = "End date is required.";
            }

            setErrors(newErrors);
        };
        if (isOpen) {
          validate();
        }
    }, [formData, isOpen, isEditMode]);


    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value, type } = e.target;
        const isNumberInput = type === 'number';
        setFormData(prev => ({ ...prev, [name]: isNumberInput ? (value === '' ? '' : parseInt(value, 10)) : value }));
    };
    
    const handleDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        try {
           const date = new Date(e.target.value);
           if(!isNaN(date.getTime())){
               setFormData(prev => ({ ...prev, endDate: date.toISOString() }));
           }
        } catch(e) { /* ignore invalid date changes */ }
    };
    
    const handleSave = () => {
        if (Object.keys(errors).length === 0) {
            onSave(formData as any);
            onClose();
        }
    };

    const handleClose = () => {
        setErrors({});
        onClose();
    };

    const isFormValid = Object.keys(errors).length === 0;

    return (
        <Modal isOpen={isOpen} onClose={handleClose} title={isEditMode ? 'Edit Raffle' : 'Create New Raffle'}>
            <div className="p-6 grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="sm:col-span-2">
                    <Input name="name" placeholder="Item Name" value={formData.name || ''} onChange={handleChange} className={errors.name ? 'border-red-500 focus:ring-red-500 focus:border-red-500' : ''} aria-invalid={!!errors.name} aria-describedby="name-error" />
                    {errors.name && <p id="name-error" className="text-red-500 text-xs mt-1">{errors.name}</p>}
                </div>
                <div className="sm:col-span-2">
                    <Input name="imageUrl" placeholder="Image URL" value={formData.imageUrl || ''} onChange={handleChange} className={errors.imageUrl ? 'border-red-500 focus:ring-red-500 focus:border-red-500' : ''} aria-invalid={!!errors.imageUrl} aria-describedby="imageUrl-error"/>
                    {errors.imageUrl && <p id="imageUrl-error" className="text-red-500 text-xs mt-1">{errors.imageUrl}</p>}
                </div>
                <div>
                    <select name="ticketCurrency" value={formData.ticketCurrency || 'TC'} onChange={handleChange} className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-md text-white focus:outline-none focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500 transition-colors">
                        <option value="TC">Tibia Coins (TC)</option>
                        <option value="BRL">Real (BRL)</option>
                    </select>
                </div>
                <div>
                    <Input name="ticketPrice" type="number" placeholder="Ticket Price" value={formData.ticketPrice || ''} onChange={handleChange} min="1" className={errors.ticketPrice ? 'border-red-500 focus:ring-red-500 focus:border-red-500' : ''} aria-invalid={!!errors.ticketPrice} aria-describedby="ticketPrice-error"/>
                    {errors.ticketPrice && <p id="ticketPrice-error" className="text-red-500 text-xs mt-1">{errors.ticketPrice}</p>}
                </div>
                <div>
                    <Input name="totalTickets" type="number" placeholder="Total Tickets" value={formData.totalTickets || ''} onChange={handleChange} min="1" className={errors.totalTickets ? 'border-red-500 focus:ring-red-500 focus:border-red-500' : ''} aria-invalid={!!errors.totalTickets} aria-describedby="totalTickets-error"/>
                    {errors.totalTickets && <p id="totalTickets-error" className="text-red-500 text-xs mt-1">{errors.totalTickets}</p>}
                </div>
                 <div>
                    <Input name="minTickets" type="number" placeholder="Minimum Tickets" value={formData.minTickets || ''} onChange={handleChange} min="1" className={errors.minTickets ? 'border-red-500 focus:ring-red-500 focus:border-red-500' : ''} aria-invalid={!!errors.minTickets} aria-describedby="minTickets-error"/>
                    {errors.minTickets && <p id="minTickets-error" className="text-red-500 text-xs mt-1">{errors.minTickets}</p>}
                </div>
                <div className="sm:col-span-2">
                    <Input name="endDate" type="datetime-local" placeholder="End Date" value={formData.endDate ? new Date(new Date(formData.endDate).getTime() - new Date(formData.endDate).getTimezoneOffset() * 60000).toISOString().slice(0, 16) : ''} onChange={handleDateChange} className={errors.endDate ? 'border-red-500 focus:ring-red-500 focus:border-red-500' : ''} aria-invalid={!!errors.endDate} aria-describedby="endDate-error"/>
                    {errors.endDate && <p id="endDate-error" className="text-red-500 text-xs mt-1">{errors.endDate}</p>}
                </div>
                <div className="flex justify-end space-x-4 pt-4 sm:col-span-2">
                    <Button onClick={handleClose} variant="secondary">Cancel</Button>
                    <Button onClick={handleSave} variant="primary" disabled={!isFormValid}>Save Changes</Button>
                </div>
            </div>
        </Modal>
    );
};

const ParticipantsModal: React.FC<{
    isOpen: boolean;
    onClose: () => void;
    raffle: RaffleItem | null;
}> = ({ isOpen, onClose, raffle }) => {
    if (!isOpen || !raffle) return null;

    const handleDownload = () => {
        if (!raffle) return;
        const participantNames = raffle.participants.map(p => p.name).join('\n');
        const blob = new Blob([participantNames], { type: 'text/plain;charset=utf-8' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        const fileName = `participants_${raffle.name.replace(/[^a-z0-9]/gi, '_').toLowerCase()}.txt`;
        link.download = fileName;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
    };

    return (
        <Modal isOpen={isOpen} onClose={onClose} title={`Participants for "${raffle.name}"`}>
            <div className="p-6">
                <div className="flex justify-between items-center mb-4">
                    <h3 className="font-bold text-lg text-gray-200">{raffle.participants.length} Entrants</h3>
                    <Button onClick={handleDownload} variant="primary">
                        <DownloadIcon className="w-5 h-5 mr-2" />
                        Download .txt
                    </Button>
                </div>
                <div className="bg-gray-900 rounded-md max-h-80 overflow-y-auto p-3 border border-gray-700">
                    {raffle.participants.length > 0 ? (
                        <ul className="space-y-2">
                            {raffle.participants.map(participant => (
                                <li key={participant.id} className="text-gray-300 bg-gray-800/50 p-2 rounded-md">
                                    {participant.name}
                                </li>
                            ))}
                        </ul>
                    ) : (
                        <p className="text-gray-500 text-center py-4">No participants yet.</p>
                    )}
                </div>
                <div className="mt-6 flex justify-end">
                    <Button onClick={onClose} variant="secondary">Close</Button>
                </div>
            </div>
        </Modal>
    );
};


const AdminPage: React.FC = () => {
    const { raffles, loading, error, refreshRaffles } = useRaffles();
    const { pending, loading: pendingLoading, refreshPending } = usePendingPurchases();
    const [isModalOpen, setModalOpen] = useState(false);
    const [isWinnerModalOpen, setWinnerModalOpen] = useState(false);
    const [isDeleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
    const [isParticipantsModalOpen, setParticipantsModalOpen] = useState(false);
    const [selectedRaffle, setSelectedRaffle] = useState<Partial<RaffleItem> | null>(null);
    const [winnerInfo, setWinnerInfo] = useState<{ winner?: Participant, announcement: string }>({ announcement: '' });
    const [isDrawing, setIsDrawing] = useState(false);

    const handleOpenModal = (raffle: Partial<RaffleItem> | null = null) => {
        setSelectedRaffle(raffle);
        setModalOpen(true);
    };

    const handleSaveRaffle = async (raffleData: Omit<RaffleItem, 'id' | 'participants' | 'winner'> | (Partial<Omit<RaffleItem, 'id'>> & { id: string })) => {
        if ('id' in raffleData && raffleData.id) {
            await raffleService.updateRaffle(raffleData.id, raffleData);
        } else {
            await raffleService.addRaffle(raffleData as Omit<RaffleItem, 'id' | 'participants' | 'winner'>);
        }
        await refreshRaffles();
    };
    
    const handleDeleteClick = (raffle: RaffleItem) => {
        setSelectedRaffle(raffle);
        setDeleteConfirmOpen(true);
    };

    const handleDeleteConfirm = async () => {
        if (selectedRaffle?.id) {
            await raffleService.deleteRaffle(selectedRaffle.id);
            await refreshRaffles();
            setDeleteConfirmOpen(false);
            setSelectedRaffle(null);
        }
    };
    
    const handleDrawWinner = useCallback(async (raffle: RaffleItem) => {
        if (raffle.participants.length < raffle.minTickets) return;
        setIsDrawing(true);
        setWinnerInfo({announcement: 'Drawing the lucky winner...'});
        setWinnerModalOpen(true);
        
        const winnerIndex = Math.floor(Math.random() * raffle.participants.length);
        const winner = raffle.participants[winnerIndex];

        const announcement = await generateWinnerAnnouncement(raffle.name, winner.name);

        setWinnerInfo({ winner, announcement });
        
        await raffleService.updateRaffle(raffle.id, { winner: winner, endDate: new Date().toISOString() });
        await refreshRaffles();
        setIsDrawing(false);

    }, [refreshRaffles]);

    const handleViewParticipants = (raffle: RaffleItem) => {
        setSelectedRaffle(raffle);
        setParticipantsModalOpen(true);
    };
    
    const handleApprovePurchase = async (purchase: PendingPurchase) => {
        try {
            await raffleService.addTicketHolder(purchase.raffleId, purchase.characterName);
            await raffleService.deletePendingPurchase(purchase.id);
            await Promise.all([refreshRaffles(), refreshPending()]);
        } catch (e: any) {
            console.error("Failed to approve purchase", e);
            alert(`Failed to approve purchase for ${purchase.characterName}. Error: ${e.message}`);
        }
    };

    const handleRejectPurchase = async (purchase: PendingPurchase) => {
         await raffleService.deletePendingPurchase(purchase.id);
         await refreshPending();
    };

    if (loading) return <div className="text-center text-xl p-10">Loading admin panel...</div>;
    if (error) return <div className="text-center text-red-500 text-xl p-10">{error}</div>;

    return (
        <div>
            <div className="flex justify-between items-center mb-6">
                <h1 className="text-4xl font-bold text-yellow-400 font-serif">Admin Dashboard</h1>
                <Button onClick={() => handleOpenModal()} variant="primary">
                    <PlusIcon className="w-5 h-5 mr-2" />
                    Create Raffle
                </Button>
            </div>
            
            <PendingVerifications 
                pendingPurchases={pending}
                onApprove={handleApprovePurchase}
                onReject={handleRejectPurchase}
                loading={pendingLoading}
            />

            <div className="bg-gray-800 rounded-lg shadow-xl overflow-x-auto">
                <table className="w-full text-left text-sm text-gray-300">
                    <thead className="bg-gray-700/50 text-xs text-gray-400 uppercase tracking-wider">
                        <tr>
                            <th className="p-3">Item</th>
                            <th className="p-3">Name</th>
                            <th className="p-3">Tickets Sold</th>
                            <th className="p-3">Price</th>
                            <th className="p-3">End Date</th>
                            <th className="p-3">Status</th>
                            <th className="p-3">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {raffles.map(raffle => (
                            <AdminRaffleRow key={raffle.id} raffle={raffle} onEdit={handleOpenModal} onDelete={handleDeleteClick} onDraw={handleDrawWinner} onViewParticipants={handleViewParticipants} />
                        ))}
                    </tbody>
                </table>
                 {raffles.length === 0 && (
                    <div className="text-center py-10 text-gray-500">
                        <p>No raffles found.</p>
                        <p className="mt-2">Click "Create Raffle" to get started!</p>
                    </div>
                )}
            </div>

            <RaffleModal isOpen={isModalOpen} onClose={() => setModalOpen(false)} onSave={handleSaveRaffle} raffle={selectedRaffle} />

            <ParticipantsModal isOpen={isParticipantsModalOpen} onClose={() => setParticipantsModalOpen(false)} raffle={selectedRaffle as RaffleItem | null} />

            {selectedRaffle && (
                <Modal isOpen={isDeleteConfirmOpen} onClose={() => setDeleteConfirmOpen(false)} title="Confirm Deletion">
                    <div className="p-6">
                        <p>Are you sure you want to delete the raffle for <strong>{selectedRaffle.name}</strong>? This action cannot be undone.</p>
                        <div className="mt-6 flex justify-end space-x-4">
                            <Button onClick={() => setDeleteConfirmOpen(false)} variant="secondary">Cancel</Button>
                            <Button onClick={handleDeleteConfirm} variant="danger">Delete</Button>
                        </div>
                    </div>
                </Modal>
            )}

            <Modal isOpen={isWinnerModalOpen} onClose={() => setWinnerModalOpen(false)} title="Raffle Winner!">
                 <div className="p-8 text-center">
                    {isDrawing ? (
                        <div className="flex flex-col items-center justify-center h-48">
                            <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-yellow-400"></div>
                            <p className="mt-4 text-lg text-gray-300">{winnerInfo.announcement}</p>
                        </div>
                    ) : (
                        <div className="space-y-4">
                            <TrophyIcon className="w-20 h-20 text-yellow-400 mx-auto animate-pulse"/>
                            <h2 className="text-2xl font-bold text-white">{winnerInfo.winner?.name}</h2>
                            <p className="text-lg text-gray-300 italic">"{winnerInfo.announcement}"</p>
                            <Button onClick={() => setWinnerModalOpen(false)} variant="primary" className="mt-6">Close</Button>
                        </div>
                    )}
                </div>
            </Modal>

        </div>
    );
};

export default AdminPage;
