
import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import { TrophyIcon } from './icons/TrophyIcon';
import { LogoutIcon } from './icons/LogoutIcon';
import Button from './ui/Button';

const Header: React.FC = () => {
  const { isAuthenticated, logout } = useAuth();
  const navigate = useNavigate();

  const activeLinkClass = 'bg-yellow-500 text-gray-900';
  const inactiveLinkClass = 'text-gray-300 hover:bg-gray-700 hover:text-white';
  
  const handleLogout = () => {
    logout();
    navigate('/raffles');
  };

  return (
    <header className="bg-gray-800 shadow-lg sticky top-0 z-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <TrophyIcon className="h-8 w-8 text-yellow-400" />
            <span className="ml-3 text-2xl font-bold text-white tracking-wider font-serif">Tibia Raffle Masters</span>
          </div>
          <nav className="flex items-center space-x-4">
            <NavLink
              to="/raffles"
              className={({ isActive }) =>
                `px-3 py-2 rounded-md text-sm font-medium transition-colors duration-200 ${isActive ? activeLinkClass : inactiveLinkClass}`
              }
            >
              Active Raffles
            </NavLink>
            {isAuthenticated ? (
               <Button onClick={handleLogout} variant="secondary" size="sm" className="!px-3 !py-2">
                 <LogoutIcon className="h-4 w-4 mr-1.5"/>
                 Logout
               </Button>
            ) : (
              <NavLink
                to="/admin"
                className={({ isActive }) =>
                  `px-3 py-2 rounded-md text-sm font-medium transition-colors duration-200 ${isActive ? activeLinkClass : inactiveLinkClass}`
                }
              >
                Admin Panel
              </NavLink>
            )}
          </nav>
        </div>
      </div>
    </header>
  );
};

export default Header;
