
import React, { useState, useEffect } from 'react';

interface CountdownTimerProps {
  endDate: string;
}

const CountdownTimer: React.FC<CountdownTimerProps> = ({ endDate }) => {
  const calculateTimeLeft = () => {
    const difference = +new Date(endDate) - +new Date();
    let timeLeft = {};

    if (difference > 0) {
      timeLeft = {
        days: Math.floor(difference / (1000 * 60 * 60 * 24)),
        hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
        minutes: Math.floor((difference / 1000 / 60) % 60),
        seconds: Math.floor((difference / 1000) % 60),
      };
    }

    return timeLeft;
  };

  const [timeLeft, setTimeLeft] = useState(calculateTimeLeft());

  useEffect(() => {
    const timer = setTimeout(() => {
      setTimeLeft(calculateTimeLeft());
    }, 1000);

    return () => clearTimeout(timer);
  });

  const timerComponents: React.ReactNode[] = [];

  Object.keys(timeLeft).forEach((interval) => {
    if (!(timeLeft as any)[interval] && interval !== 'seconds' && Object.keys(timerComponents).length === 0) {
        // Don't render 0 days if there are no days left
        if((timeLeft as any)['days'] === 0 && interval === 'days') return;
    }
    
    timerComponents.push(
      <div key={interval} className="text-center">
        <span className="text-2xl font-bold text-white">{(timeLeft as any)[interval].toString().padStart(2, '0')}</span>
        <span className="text-xs text-gray-400 uppercase">{interval}</span>
      </div>
    );
  });
  
  return (
    <div className="grid grid-cols-4 gap-2 p-3 bg-gray-700/50 rounded-md text-center">
        {timerComponents.length ? timerComponents : <span className="col-span-4 font-bold text-red-500">Time's up!</span>}
    </div>
  );
};

export default CountdownTimer;
