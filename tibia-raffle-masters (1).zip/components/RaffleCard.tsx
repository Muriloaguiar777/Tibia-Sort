
import React from 'react';
import { RaffleItem } from '../types';
import CountdownTimer from './CountdownTimer';
import Button from './ui/Button';
import { TicketIcon } from './icons/TicketIcon';
import { formatCurrency } from '../services/raffleService';

interface RaffleCardProps {
  raffle: RaffleItem;
  onBuyClick: (raffle: RaffleItem) => void;
}

const RaffleCard: React.FC<RaffleCardProps> = ({ raffle, onBuyClick }) => {
  const ticketsSold = raffle.participants.length;
  const progress = (ticketsSold / raffle.totalTickets) * 100;
  const isFinished = new Date(raffle.endDate) < new Date() || !!raffle.winner;
  const isSoldOut = ticketsSold >= raffle.totalTickets;

  const getFinishedStatusText = () => {
    if (raffle.winner) return 'WINNER DRAWN';
    if (raffle.participants.length < raffle.minTickets) return 'MIN. NOT MET';
    return 'RAFFLE ENDED';
  };
  
  const statusText = getFinishedStatusText();
  const statusColor = statusText === 'WINNER DRAWN' ? 'text-green-500' : 'text-red-500';

  return (
    <div className={`bg-gray-800 rounded-lg shadow-xl overflow-hidden flex flex-col transition-all duration-300 transform hover:-translate-y-1 ${isFinished ? 'opacity-70' : ''}`}>
      <div className="relative p-4 bg-gray-900/50 flex justify-center items-center h-48">
        <img src={raffle.imageUrl} alt={raffle.name} className="max-h-full max-w-full object-contain" />
        {isFinished && raffle.winner && (
           <div className="absolute inset-0 bg-black/70 flex flex-col justify-center items-center text-center p-4">
                <span className="text-sm text-gray-400">Winner</span>
                <span className="text-2xl font-bold text-yellow-400">{raffle.winner.name}</span>
            </div>
        )}
      </div>
      <div className="p-6 flex-grow flex flex-col">
        <h3 className="text-2xl font-bold text-white mb-2">{raffle.name}</h3>
        <div className="flex-grow">
          <div className="w-full bg-gray-700 rounded-full h-2.5 mb-2">
            <div className="bg-yellow-500 h-2.5 rounded-full" style={{ width: `${progress}%` }}></div>
          </div>
          <div className="flex justify-between text-sm text-gray-400 mb-4">
            <span>{ticketsSold} / {raffle.totalTickets} <span className="text-xs">(min {raffle.minTickets})</span></span>
            <span className="font-semibold text-yellow-400">{formatCurrency(raffle.ticketPrice, raffle.ticketCurrency)}</span>
          </div>
        </div>
        <div className="mt-auto">
          {isFinished ? (
            <div className={`text-center font-bold ${statusColor} p-3 bg-gray-700/50 rounded-md`}>
              {statusText}
            </div>
          ) : (
            <>
              <div className="mb-4">
                <CountdownTimer endDate={raffle.endDate} />
              </div>
              <Button onClick={() => onBuyClick(raffle)} disabled={isSoldOut} variant="primary" className="w-full">
                <TicketIcon className="w-5 h-5 mr-2" />
                {isSoldOut ? 'Sold Out' : 'Buy Ticket'}
              </Button>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default RaffleCard;
