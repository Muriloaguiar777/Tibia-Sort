
import { GoogleGenAI } from "@google/genai";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  console.warn("Gemini API key not found. Winner announcements will be generic. Please set the 'API_KEY' environment variable.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY! });

export const generateWinnerAnnouncement = async (itemName: string, winnerName: string): Promise<string> => {
  if (!API_KEY) {
    return `Congratulations to ${winnerName} for winning the ${itemName}! A fantastic prize for a lucky adventurer!`;
  }

  const prompt = `You are a charismatic town crier in the medieval fantasy world of Tibia. Your voice booms with excitement. Announce the winner of a grand raffle for a legendary item.

Item: "${itemName}"
Winner: "${winnerName}"

Craft a short, epic, and celebratory announcement of 2-3 sentences. Make it sound like a momentous occasion. Do not use markdown.`;

  try {
    const response = await ai.models.generateContent({
        model: "gemini-2.5-flash-preview-04-17",
        contents: prompt,
        config: { thinkingConfig: { thinkingBudget: 0 } }
    });
    return response.text.trim();
  } catch (error) {
    console.error("Error generating winner announcement with Gemini:", error);
    // Fallback to a generic message in case of API error
    return `Hark, adventurers! By a stroke of immense luck, ${winnerName} has won the legendary ${itemName}! May it serve you well in your epic journeys!`;
  }
};
