import { RaffleItem, Currency, PendingPurchase } from '../types';
import { handleApiRequest } from './mockApi';

// --- Helper Functions (Client-side formatting and conversion) ---

export const EXCHANGE_RATES = {
  TC_PER_BRL: 5,
};

export const convertCurrency = (amount: number, from: Currency, to: Currency): number => {
  if (from === to) return amount;

  if (from === 'TC' && to === 'BRL') {
    return amount / EXCHANGE_RATES.TC_PER_BRL;
  }
  
  if (from === 'BRL' && to === 'TC') {
    return amount * EXCHANGE_RATES.TC_PER_BRL;
  }
  
  return amount;
};

export const formatCurrency = (price: number, currency: Currency): string => {
  try {
    switch (currency) {
      case 'TC':
        return `${Math.round(price).toLocaleString('en-US')} TC`;
      case 'BRL':
        return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(price);
      default:
        return `${price.toLocaleString('en-US')}`;
    }
  } catch (e) {
    return `${price} ${currency}`;
  }
};


// --- API Client Functions ---

const handleResponse = async (response: Response) => {
    if (!response.ok) {
        const error = await response.json().catch(() => ({ message: response.statusText }));
        throw new Error(error.message || 'An API error occurred');
    }
    if (response.status === 204) { // No Content
        return;
    }
    return response.json();
};

const apiFetch = async (url: string, options?: RequestInit) => {
    const headers = {
        'Content-Type': 'application/json',
        ...options?.headers,
    };
    // Call the mock API handler directly instead of the native fetch
    const response = await handleApiRequest(url, { ...options, headers });
    return handleResponse(response);
};

export const getRaffles = async (): Promise<RaffleItem[]> => {
  return apiFetch('/api/raffles');
};

export const addRaffle = async (item: Omit<RaffleItem, 'id' | 'participants' | 'winner'>): Promise<RaffleItem> => {
  return apiFetch('/api/raffles', {
    method: 'POST',
    body: JSON.stringify(item),
  });
};

export const updateRaffle = async (id: string, updates: Partial<Omit<RaffleItem, 'id'>>): Promise<RaffleItem> => {
  return apiFetch(`/api/raffles/${id}`, {
    method: 'PUT',
    body: JSON.stringify(updates),
  });
};

export const deleteRaffle = async (id: string): Promise<void> => {
  return apiFetch(`/api/raffles/${id}`, {
    method: 'DELETE',
  });
};

export const addTicketHolder = async (raffleId: string, participantName: string): Promise<RaffleItem> => {
    return apiFetch(`/api/raffles/${raffleId}/participants`, {
        method: 'POST',
        body: JSON.stringify({ participantName }),
    });
};

export const getPendingPurchases = async (): Promise<PendingPurchase[]> => {
  return apiFetch('/api/pending-purchases');
};

export const addPendingPurchase = async (raffleId: string, raffleName: string, characterName: string, currency: Currency, amount: number): Promise<PendingPurchase> => {
    const payload = { raffleId, raffleName, characterName, currency, amount };
    return apiFetch('/api/pending-purchases', {
        method: 'POST',
        body: JSON.stringify(payload),
    });
};

export const deletePendingPurchase = async (id: string): Promise<void> => {
    return apiFetch(`/api/pending-purchases/${id}`, {
        method: 'DELETE',
    });
};