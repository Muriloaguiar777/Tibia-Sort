import { RaffleItem, PendingPurchase, Participant } from '../types';

const RAFFLES_KEY = 'tibiaRaffles';
const PENDING_PURCHASES_KEY = 'tibiaPendingPurchases';

// --- Seed Data for a better first-run experience ---

const initialRaffles: RaffleItem[] = [
  {
    id: '1',
    name: 'Magic Longsword',
    imageUrl: 'https://static.tibia.com/images/library/magiclongsword.gif',
    ticketPrice: 25,
    ticketCurrency: 'TC',
    totalTickets: 100,
    minTickets: 20,
    endDate: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString(),
    participants: [
      { id: 'p1', name: 'Brave Warrior' },
      { id: 'p2', name: 'Knight Alex' },
    ],
  },
  {
    id: '2',
    name: 'Golden Armor',
    imageUrl: 'https://static.tibia.com/images/library/goldenarmor.gif',
    ticketPrice: 50,
    ticketCurrency: 'TC',
    totalTickets: 150,
    minTickets: 50,
    endDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
    participants: Array.from({ length: 45 }, (_, i) => ({ id: `p_ga_${i}`, name: `Adventurer ${i + 1}` })),
  },
    {
    id: '3',
    name: 'Demon Helmet',
    imageUrl: 'https://static.tibia.com/images/library/demonhelmet.gif',
    ticketPrice: 15,
    ticketCurrency: 'BRL',
    totalTickets: 200,
    minTickets: 100,
    endDate: new Date(Date.now() + 10 * 24 * 60 * 60 * 1000).toISOString(),
    participants: Array.from({ length: 198 }, (_, i) => ({ id: `p_dh_${i}`, name: `Treasure Hunter ${i + 1}` })),
    },
  {
    id: '4',
    name: 'Ferumbras\' Hat',
    imageUrl: 'https://static.tibia.com/images/library/ferumbras_hat.gif',
    ticketPrice: 500,
    ticketCurrency: 'TC',
    totalTickets: 50,
    minTickets: 25,
    endDate: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
    participants: Array.from({ length: 30 }, (_, i) => ({ id: `p_fh_${i}`, name: `Mage ${i + 1}` })),
    winner: { id: 'p_fh_15', name: 'Grand Sorcerer' }
  },
    {
    id: '5',
    name: 'Great Shield',
    imageUrl: 'https://static.tibia.com/images/library/greatshield.gif',
    ticketPrice: 10,
    ticketCurrency: 'TC',
    totalTickets: 100,
    minTickets: 50,
    endDate: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
    participants: Array.from({ length: 40 }, (_, i) => ({ id: `p_gs_${i}`, name: `Guardian ${i + 1}` })),
  }
];

const initialPending: PendingPurchase[] = [
    {
        id: 'pp1',
        raffleId: '2',
        raffleName: 'Golden Armor',
        characterName: 'Rich Paladin',
        currency: 'TC',
        amount: 50
    },
    {
        id: 'pp2',
        raffleId: '3',
        raffleName: 'Demon Helmet',
        characterName: 'Smart Druid',
        currency: 'BRL',
        amount: 15
    }
];


// --- LocalStorage Helpers ---

const getFromStorage = <T>(key: string, defaultValue: T): T => {
    try {
        const item = localStorage.getItem(key);
        return item ? JSON.parse(item) : defaultValue;
    } catch (error) {
        console.error(`Error reading from localStorage key “${key}”:`, error);
        return defaultValue;
    }
};

const saveToStorage = <T>(key: string, value: T) => {
    try {
        localStorage.setItem(key, JSON.stringify(value));
    } catch (error) {
        console.error(`Error writing to localStorage key “${key}”:`, error);
    }
};

// --- Mock API Request Handler ---

export const handleApiRequest = async (input: RequestInfo | URL, init?: RequestInit): Promise<Response> => {
    const url = typeof input === 'string' ? input : ('url' in input ? input.url : input.href);
    const method = init?.method?.toUpperCase() || 'GET';
    const body = init?.body ? JSON.parse(init.body as string) : {};

    console.log(`[Mock API] Handling: ${method} ${url}`);

    // Simulate network delay
    await new Promise(resolve => setTimeout(resolve, 300 + Math.random() * 400));

    const rafflesRegex = /^\/api\/raffles\/?$/;
    const raffleByIdRegex = /^\/api\/raffles\/([a-zA-Z0-9-]+)\/?$/;
    const raffleParticipantsRegex = /^\/api\/raffles\/([a-zA-Z0-9-]+)\/participants\/?$/;
    const pendingPurchasesRegex = /^\/api\/pending-purchases\/?$/;
    const pendingPurchaseByIdRegex = /^\/api\/pending-purchases\/([a-zA-Z0-9-]+)\/?$/;

    let raffles = getFromStorage<RaffleItem[]>(RAFFLES_KEY, []);
    let pendingPurchases = getFromStorage<PendingPurchase[]>(PENDING_PURCHASES_KEY, []);

    // --- Raffles Endpoints ---

    // GET /api/raffles
    if (method === 'GET' && rafflesRegex.test(url)) {
        return new Response(JSON.stringify(raffles), { status: 200, headers: { 'Content-Type': 'application/json' } });
    }

    // POST /api/raffles
    if (method === 'POST' && rafflesRegex.test(url)) {
        const newRaffle: RaffleItem = { ...body, id: crypto.randomUUID(), participants: [] };
        raffles.push(newRaffle);
        saveToStorage(RAFFLES_KEY, raffles);
        return new Response(JSON.stringify(newRaffle), { status: 201, headers: { 'Content-Type': 'application/json' } });
    }

    const raffleByIdMatch = url.match(raffleByIdRegex);
    if (raffleByIdMatch) {
        const id = raffleByIdMatch[1];
        const raffleIndex = raffles.findIndex(r => r.id === id);

        if (raffleIndex === -1) {
            return new Response(JSON.stringify({ message: `Raffle with id ${id} not found` }), { status: 404, headers: { 'Content-Type': 'application/json' } });
        }

        // PUT /api/raffles/:id
        if (method === 'PUT') {
            raffles[raffleIndex] = { ...raffles[raffleIndex], ...body };
            saveToStorage(RAFFLES_KEY, raffles);
            return new Response(JSON.stringify(raffles[raffleIndex]), { status: 200, headers: { 'Content-Type': 'application/json' } });
        }

        // DELETE /api/raffles/:id
        if (method === 'DELETE') {
            raffles.splice(raffleIndex, 1);
            saveToStorage(RAFFLES_KEY, raffles);
            return new Response(null, { status: 204 });
        }
    }
    
    // POST /api/raffles/:id/participants
    const raffleParticipantsMatch = url.match(raffleParticipantsRegex);
    if (method === 'POST' && raffleParticipantsMatch) {
        const raffleId = raffleParticipantsMatch[1];
        const raffle = raffles.find(r => r.id === raffleId);
        if (raffle) {
            const newParticipant: Participant = { id: crypto.randomUUID(), name: body.participantName };
            raffle.participants.push(newParticipant);
            saveToStorage(RAFFLES_KEY, raffles);
            return new Response(JSON.stringify(raffle), { status: 200, headers: { 'Content-Type': 'application/json' } });
        }
        return new Response(JSON.stringify({ message: `Raffle with id ${raffleId} not found` }), { status: 404, headers: { 'Content-Type': 'application/json' } });
    }

    // --- Pending Purchases Endpoints ---

    // GET /api/pending-purchases
    if (method === 'GET' && pendingPurchasesRegex.test(url)) {
        return new Response(JSON.stringify(pendingPurchases), { status: 200, headers: { 'Content-Type': 'application/json' } });
    }
    
    // POST /api/pending-purchases
    if (method === 'POST' && pendingPurchasesRegex.test(url)) {
        const newPurchase: PendingPurchase = { ...body, id: crypto.randomUUID() };
        pendingPurchases.push(newPurchase);
        saveToStorage(PENDING_PURCHASES_KEY, pendingPurchases);
        return new Response(JSON.stringify(newPurchase), { status: 201, headers: { 'Content-Type': 'application/json' } });
    }
    
    // DELETE /api/pending-purchases/:id
    const pendingPurchaseByIdMatch = url.match(pendingPurchaseByIdRegex);
    if (method === 'DELETE' && pendingPurchaseByIdMatch) {
        const id = pendingPurchaseByIdMatch[1];
        const initialLength = pendingPurchases.length;
        pendingPurchases = pendingPurchases.filter(p => p.id !== id);
        if (pendingPurchases.length < initialLength) {
            saveToStorage(PENDING_PURCHASES_KEY, pendingPurchases);
            return new Response(null, { status: 204 });
        }
        return new Response(JSON.stringify({ message: `Pending purchase with id ${id} not found` }), { status: 404, headers: { 'Content-Type': 'application/json' } });
    }
    
    console.warn(`[Mock API] Unhandled route: ${method} ${url}`);
    return new Response(JSON.stringify({ message: `Route ${method} ${url} not found.` }), { status: 404, headers: { 'Content-Type': 'application/json' } });
};

export const startMockApi = () => {
    // Initialize storage if it's empty
    if (!localStorage.getItem(RAFFLES_KEY)) {
        saveToStorage(RAFFLES_KEY, initialRaffles);
    }
    if (!localStorage.getItem(PENDING_PURCHASES_KEY)) {
        saveToStorage(PENDING_PURCHASES_KEY, initialPending);
    }
    console.log("Mock API data initialized.");
};